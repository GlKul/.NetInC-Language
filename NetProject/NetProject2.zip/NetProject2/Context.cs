﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetProject2
{
    class Context : DbContext
    {
        public virtual DbSet<Course> Courses { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<CourseTeacher> CourseTeachers { get; set; }
        public DbSet<CourseStudent> CourseStudents { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var config = new ConfigurationBuilder()
                            .AddJsonFile("appsettings.json")
                            .SetBasePath(Directory.GetCurrentDirectory())
                            .Build();

            optionsBuilder.UseSqlite(config.GetConnectionString("DefaultConnection"));

            optionsBuilder.UseLazyLoadingProxies()
              .UseSqlite(config.GetConnectionString("DefaultConnection"));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Настройка связи Course-Teacher
            modelBuilder.Entity<CourseTeacher>()
                .HasKey(ct => new { ct.CourseId, ct.TeacherId });

            modelBuilder.Entity<CourseTeacher>()
                .HasOne(ct => ct.Course)
                .WithMany(c => c.CourseTeachers)
                .HasForeignKey(ct => ct.CourseId);

            modelBuilder.Entity<CourseTeacher>()
                .HasOne(ct => ct.Teacher)
                .WithMany(t => t.CourseTeachers)
                .HasForeignKey(ct => ct.TeacherId);

            // Настройка связи Course-Student
            modelBuilder.Entity<CourseStudent>()
                .HasKey(cs => new { cs.CourseId, cs.StudentId });

            modelBuilder.Entity<CourseStudent>()
                .HasOne(cs => cs.Course)
                .WithMany(c => c.CourseStudents)
                .HasForeignKey(cs => cs.CourseId);

            modelBuilder.Entity<CourseStudent>()
                .HasOne(cs => cs.Student)
                .WithMany(s => s.CourseStudents)
                .HasForeignKey(cs => cs.StudentId);
        }

        public void SeedData()
        {
            if (!Students.Any() && !Courses.Any() && !Teachers.Any())
            {
                Student s1 = new Student { Name = "Vasya"};
                Student s2 = new Student { Name = "Ivan"};
                Student s3 = new Student { Name = "Petr"};

                Students.Add(s1);
                Students.Add(s2);

                Course course1 = new Course { Title = "Математика", Duration = 144, Description = "IMIT1&3"};
                Course course2 = new Course { Title = "Физика", Duration = 144, Description = " IMIT2"};

                Courses.Add(course1);
                Courses.Add(course2);

                Teacher t1 = new Teacher { Name = "Alex" };
                Teacher t2 = new Teacher { Name = "Sergey" };
                Teachers.AddRange(t1, t2);

                SaveChanges();

                // Создание связей
                CourseTeachers.AddRange(
                    new CourseTeacher { CourseId = course1.CourseId, TeacherId = t1.Id },
                    new CourseTeacher { CourseId = course2.CourseId, TeacherId = t2.Id }
                );

                CourseStudents.AddRange(
                    new CourseStudent { CourseId = course1.CourseId, StudentId = s1.Id },
                    new CourseStudent { CourseId = course1.CourseId, StudentId = s2.Id },
                    new CourseStudent { CourseId = course2.CourseId, StudentId = s1.Id }
                );
                SaveChanges();
            }
        }
    }
}
